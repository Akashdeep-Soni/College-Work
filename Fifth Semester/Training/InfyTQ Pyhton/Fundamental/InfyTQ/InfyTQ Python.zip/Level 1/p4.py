#PF-Prac-4

def find_nine(nums):

    #Remove pass and write your code here

	return True if 9 in nums[:4] else False

    



nums=[1,9,4,5,6]

print(find_nine(nums))