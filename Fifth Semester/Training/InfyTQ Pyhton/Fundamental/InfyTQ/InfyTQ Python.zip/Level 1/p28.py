#PF-Tryout
def sing_99_bottles():
   #start writing your code here
   for i in range(99,0,-1):
       print("{0} bottles of beer on the wall, {0} bottles of beer".format(i))
   
sing_99_bottles()