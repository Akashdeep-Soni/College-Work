#PF-Tryout
def diagonal_stars(number):
   #start writing your code here
   for i in range(number):
       print('.'*i + '*')

number=6    
diagonal_stars(number)